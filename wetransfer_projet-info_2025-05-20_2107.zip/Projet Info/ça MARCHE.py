# -*- coding: utf-8 -*-
"""
Created on Wed May 21 21:30:58 2025

@author: fonta
"""

# -*- coding: utf-8 -*-
"""
Technical Analysis App

Merged with dynamic data loader and start-date selection
"""
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime

class TechnicalAnalysisApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Analyse Technique Avancée")

        # Variables pour les paramètres
        self.indicator_var = tk.StringVar(value="MACD")
        self.ema_short_var = tk.IntVar(value=12)
        self.ema_long_var = tk.IntVar(value=26)
        self.signal_var = tk.IntVar(value=9)
        self.rsi_period_var = tk.IntVar(value=14)
        self.bb_period_var = tk.IntVar(value=20)
        self.bb_dev_var = tk.DoubleVar(value=2.0)
        self.stoch_k_var = tk.IntVar(value=14)
        self.stoch_d_var = tk.IntVar(value=3)
        self.sar_accel_var = tk.DoubleVar(value=0.02)
        self.sar_max_var = tk.DoubleVar(value=0.2)
        self.atr_period_var = tk.IntVar(value=14)
        self.hold_days_var = tk.IntVar(value=5)
        self.risk_reward_var = tk.DoubleVar(value=1.0)
        self.risk_percent_var = tk.DoubleVar(value=1.0)
        self.start_date_var = tk.StringVar(value="")

        # Structure principale
        self.main_frame = ttk.Frame(root, padding="10")
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self.main_frame.grid_rowconfigure(2, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

        # Contrôles initiaux
        control_frame = ttk.Frame(self.main_frame)
        control_frame.grid(row=0, column=0, sticky="ew", padx=5, pady=5)

        # Chargement et période
        ttk.Button(control_frame, text="Charger Données", command=self.load_data).pack(side=tk.LEFT, padx=5)
        date_frame = ttk.LabelFrame(control_frame, text="Période", padding="5")
        date_frame.pack(side=tk.LEFT, padx=5)
        ttk.Label(date_frame, text="Date début (YYYY-MM-DD):").pack(side=tk.LEFT)
        ttk.Entry(date_frame, textvariable=self.start_date_var, width=12).pack(side=tk.LEFT)

        # Sélecteur d'indicateur
        indicator_frame = ttk.LabelFrame(control_frame, text="Indicateur", padding="5")
        indicator_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        indicators = ["MACD", "RSI", "Bollinger Bands", "Stochastic", "Parabolic SAR", "ATR", "OBV"]
        ttk.OptionMenu(indicator_frame, self.indicator_var, indicators[0], *indicators).pack()
        ttk.Button(indicator_frame, text="Configurer", command=self.show_indicator_params).pack(pady=5)

        # Paramètres de trading
        trading_frame = ttk.LabelFrame(control_frame, text="Paramètres Trading", padding="5")
        trading_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        ttk.Label(trading_frame, text="Durée (jours):").grid(row=0, column=0, sticky="w")
        ttk.Spinbox(trading_frame, from_=1, to=30, textvariable=self.hold_days_var, width=5).grid(row=0, column=1)
        ttk.Label(trading_frame, text="Ratio R/R:").grid(row=1, column=0, sticky="w")
        ttk.Spinbox(trading_frame, from_=0.5, to=5, increment=0.1, textvariable=self.risk_reward_var, width=5).grid(row=1, column=1)
        ttk.Label(trading_frame, text="Risque (%):").grid(row=2, column=0, sticky="w")
        ttk.Spinbox(trading_frame, from_=0.1, to=10, increment=0.1, textvariable=self.risk_percent_var, width=5).grid(row=2, column=1)

        ttk.Button(control_frame, text="Lancer l'Analyse", command=self.run_analysis).pack(side=tk.LEFT, padx=10)

        # Zone de statut et informations fichier
        self.status_label = ttk.Label(self.main_frame, text="Aucun fichier chargé", foreground="blue")
        self.status_label.grid(row=3, column=0, sticky="w", padx=5, pady=(5,0))
        self.result_text = tk.Text(self.main_frame, height=3)
        self.result_text.grid(row=4, column=0, sticky="ew", padx=5)

        # Paramètres indicateur
        self.param_frame = ttk.LabelFrame(self.main_frame, text="Paramètres Indicateur", padding="10")
        self.param_frame.grid(row=1, column=0, sticky="ew", padx=5, pady=5)

        # Résultats et graphique
        results_graph_frame = ttk.Frame(self.main_frame)
        results_graph_frame.grid(row=5, column=0, sticky="nsew", padx=5, pady=5)
        self.results_frame = ttk.LabelFrame(results_graph_frame, text="Performance", padding="10")
        self.results_frame.pack(side=tk.LEFT, fill=tk.Y, padx=5)
        ttk.Button(self.results_frame, text="Afficher Graphique", command=self.toggle_graph).pack(pady=5)
        self.graph_frame = ttk.Frame(results_graph_frame)
        self.graph_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Données initiales vides
        self.data = pd.DataFrame()

    def load_data(self, file_path=None):
        """Charge un fichier CSV et prépare les données"""
        try:
            if not file_path:
                file_path = filedialog.askopenfilename(
                    title="Sélectionner un fichier CSV",
                    filetypes=[("Fichiers CSV", "*.csv"), ("Tous les fichiers", "*.*")]
                )
                if not file_path:
                    return
            # Essai encodage utf-16
            try:
                df = pd.read_csv(file_path, encoding="utf-16", header=None)
            except Exception:
                df = pd.read_csv(file_path, encoding="utf-8", header=None)
            # Configurer colonnes
            if df.shape[1] >= 6:
                cols = ["Date", "Open", "High", "Low", "Close", "Volume"]
                if df.shape[1] > 6:
                    cols.append("Extra")
                df.columns = cols[:df.shape[1]]
            # Nettoyage
            df['Date'] = pd.to_datetime(df['Date'], format='%Y.%m.%d', errors='coerce')
            df['Close'] = pd.to_numeric(df['Close'], errors='coerce')
            df.dropna(subset=['Date','Close'], inplace=True)
            df.set_index('Date', inplace=True)

            self.data = df.sort_index()
            # Info
            self.status_label.config(text=f"Fichier chargé: {os.path.basename(file_path)}")
            self.result_text.delete('1.0', tk.END)
            self.result_text.insert(tk.END,
                f"Données chargées:\nPériode: {self.data.index.min().date()} à {self.data.index.max().date()}\nLignes: {len(self.data)}"
            )
        except Exception as e:
            self.status_label.config(text=f"Erreur de chargement", foreground="red")
            messagebox.showerror("Erreur", f"Erreur de chargement: {e}")

    def show_indicator_params(self):
        for widget in self.param_frame.winfo_children():
            widget.destroy()
        ind = self.indicator_var.get()
        
        if ind == "MACD":
            ttk.Label(self.param_frame, text="EMA Courte:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.ema_short_var).grid(row=0, column=1)
            
            ttk.Label(self.param_frame, text="EMA Longue:").grid(row=1, column=0)
            ttk.Spinbox(self.param_frame, from_=10, to=100, textvariable=self.ema_long_var).grid(row=1, column=1)
            
            ttk.Label(self.param_frame, text="Signal:").grid(row=2, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.signal_var).grid(row=2, column=1)
        
        elif ind == "RSI":
            ttk.Label(self.param_frame, text="Période RSI:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.rsi_period_var).grid(row=0, column=1)
        
        elif ind == "Bollinger Bands":
            ttk.Label(self.param_frame, text="Période:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.bb_period_var).grid(row=0, column=1)
            
            ttk.Label(self.param_frame, text="Déviation:").grid(row=1, column=0)
            ttk.Spinbox(self.param_frame, from_=0.5, to=5, increment=0.1, textvariable=self.bb_dev_var).grid(row=1, column=1)
        
        elif ind == "Stochastic":
            ttk.Label(self.param_frame, text="%K Période:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.stoch_k_var).grid(row=0, column=1)
            
            ttk.Label(self.param_frame, text="%D Période:").grid(row=1, column=0)
            ttk.Spinbox(self.param_frame, from_=1, to=20, textvariable=self.stoch_d_var).grid(row=1, column=1)
        
        elif ind == "Parabolic SAR":
            ttk.Label(self.param_frame, text="Accélération:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=0.01, to=0.2, increment=0.01, textvariable=self.sar_accel_var).grid(row=0, column=1)
            
            ttk.Label(self.param_frame, text="Maximum:").grid(row=1, column=0)
            ttk.Spinbox(self.param_frame, from_=0.1, to=0.5, increment=0.01, textvariable=self.sar_max_var).grid(row=1, column=1)
        
        elif ind == "ATR":
            ttk.Label(self.param_frame, text="Période:").grid(row=0, column=0)
            ttk.Spinbox(self.param_frame, from_=5, to=50, textvariable=self.atr_period_var).grid(row=0, column=1)
        
        elif ind == "OBV":
            ttk.Label(self.param_frame, text="Pas de paramètres").grid(row=0, column=0)
    
    def calculate_macd(self):
        short = self.ema_short_var.get()
        long = self.ema_long_var.get()
        sig = self.signal_var.get()
        df = self.data_recent
        df['EMA_short'] = df['Close'].ewm(span=short, adjust=False).mean()
        df['EMA_long'] = df['Close'].ewm(span=long, adjust=False).mean()
        df['MACD'] = df['EMA_short'] - df['EMA_long']
        df['Signal'] = df['MACD'].ewm(span=sig, adjust=False).mean()
        df['Position'] = 0
        df.loc[df['MACD'] > df['Signal'], 'Position'] = 1
        df.loc[df['MACD'] < df['Signal'], 'Position'] = -1

    def calculate_rsi(self):
        per = self.rsi_period_var.get()
        df = self.data_recent
        delta = df['Close'].diff()
        gain = delta.where(delta>0,0).rolling(per).mean()
        loss = -delta.where(delta<0,0).rolling(per).mean()
        rs = gain/loss
        df['RSI'] = 100 - 100/(1+rs)
        df['Position'] = 0
        df.loc[df['RSI'] < 30, 'Position'] = 1
        df.loc[df['RSI'] > 70, 'Position'] = -1

    def calculate_bollinger(self):
        per = self.bb_period_var.get()
        dev = self.bb_dev_var.get()
        df = self.data_recent
        df['MA'] = df['Close'].rolling(per).mean()
        df['STD'] = df['Close'].rolling(per).std()
        df['Upper'] = df['MA'] + dev*df['STD']
        df['Lower'] = df['MA'] - dev*df['STD']
        df['Position'] = 0
        df.loc[df['Close'] <= df['Lower'], 'Position'] = 1
        df.loc[df['Close'] >= df['Upper'], 'Position'] = -1

    def calculate_stochastic(self):
        k = self.stoch_k_var.get()
        d = self.stoch_d_var.get()
        df = self.data_recent
        low = df['Low'].rolling(k).min()
        high = df['High'].rolling(k).max()
        df['%K'] = 100*(df['Close']-low)/(high-low)
        df['%D'] = df['%K'].rolling(d).mean()
        df['Position'] = 0
        df.loc[(df['%K']<20)&(df['%D']<20), 'Position'] = 1
        df.loc[(df['%K']>80)&(df['%D']>80), 'Position'] = -1

    def calculate_sar(self):
        accel = self.sar_accel_var.get()
        maxaf = self.sar_max_var.get()
        df = self.data_recent
        sar = df['Close'].copy()
        trend = 1
        ep = df['High'].iloc[0]
        af = accel
        for i in range(1,len(df)):
            prev = sar.iloc[i-1]
            if trend==1:
                sar.iloc[i] = prev + af*(ep-prev)
                if df['Low'].iloc[i] < sar.iloc[i]:
                    trend=-1; sar.iloc[i]=ep; ep=df['Low'].iloc[i]; af=accel
                else:
                    if df['High'].iloc[i]>ep: ep=df['High'].iloc[i]; af=min(af+accel,maxaf)
            else:
                sar.iloc[i] = prev + af*(ep-prev)
                if df['High'].iloc[i] > sar.iloc[i]:
                    trend=1; sar.iloc[i]=ep; ep=df['High'].iloc[i]; af=accel
                else:
                    if df['Low'].iloc[i]<ep: ep=df['Low'].iloc[i]; af=min(af+accel,maxaf)
        df['SAR'] = sar
        df['Position'] = np.where(df['Close']>df['SAR'],1,-1)

    def calculate_atr(self):
        per = self.atr_period_var.get()
        df = self.data_recent
        tr = pd.concat([df['High']-df['Low'],
                        (df['High']-df['Close'].shift()).abs(),
                        (df['Low']-df['Close'].shift()).abs()],axis=1).max(axis=1)
        df['ATR'] = tr.rolling(per).mean()
        df['Position'] = np.where(df['Close']>df['Close'].shift(),1,-1)

    def calculate_obv(self):
        df = self.data_recent
        df['OBV'] = (np.sign(df['Close'].diff())*df['Volume']).cumsum()
        df['Position'] = np.sign(df['OBV'].diff()).fillna(0)

    def run_analysis(self):
        """Exécute l'analyse sur la période sélectionnée"""
        if self.data.empty:
            messagebox.showwarning("Avertissement", "Veuillez d'abord charger un fichier de données.")
            return
        # Filtrer par date
        try:
            start = pd.to_datetime(self.start_date_var.get(), format='%Y-%m-%d')
        except Exception:
            messagebox.showerror("Erreur date", "Date de début invalide. Utilisez YYYY-MM-DD.")
            return
        end = datetime.today()
        self.data_recent = self.data.loc[start:end].copy()
        if self.data_recent.empty:
            messagebox.showwarning("Avertissement", "Aucune donnée pour la période sélectionnée.")
            return
        # Calculs
        try:
            ind = self.indicator_var.get()
            if ind == "MACD": self.calculate_macd()
            elif ind == "RSI": self.calculate_rsi()
            elif ind == "Bollinger Bands": self.calculate_bollinger()
            elif ind == "Stochastic": self.calculate_stochastic()
            elif ind == "Parabolic SAR": self.calculate_sar()
            elif ind == "ATR": self.calculate_atr()
            elif ind == "OBV": self.calculate_obv()
            self.calculate_performance()
            self.show_results()
            self.plot_results()
        except Exception as e:
            messagebox.showerror("Erreur", f"Analyse impossible: {e}")
    
    def toggle_graph(self):
        """Affiche ou masque le graphique"""
        if hasattr(self, 'graph_canvas'):
            if self.graph_canvas.get_tk_widget().winfo_ismapped():
                self.graph_canvas.get_tk_widget().pack_forget()
            else:
                self.graph_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        else:
            self.plot_results()
    
    def calculate_performance(self):
        """Calcule les performances avec gestion précise des positions"""
        hold_days = self.hold_days_var.get()
        risk_reward = self.risk_reward_var.get()
        risk_percent = self.risk_percent_var.get() / 100
        
        in_position = False
        current_position = 0
        entry_date = None
        entry_price = None
        results = []
        equity = 10000  # Capital initial pour calcul du drawdown
        equity_curve = []
        
        for i in range(len(self.data_recent)):
            date = self.data_recent.index[i]
            position = self.data_recent['Position'].iloc[i]
            price = self.data_recent['Close'].iloc[i]
            
            # Entrée en position
            if not in_position and position != 0:
                in_position = True
                current_position = position
                entry_date = date
                entry_price = price
                continue
            
            # Sortie de position
            if in_position:
                exit_condition = (
                    (position == -current_position) or  # Signal inverse
                    ((date - entry_date).days >= hold_days)  # Durée max atteinte
                )
                
                if exit_condition:
                    exit_date = date
                    exit_price = price
                    days_held = (exit_date - entry_date).days
                    
                    # Calcul du profit
                    if current_position == 1:  # Achat
                        profit_pct = (exit_price - entry_price) / entry_price * 100
                    else:  # Vente
                        profit_pct = (entry_price - exit_price) / entry_price * 100
                    
                    # Mise à jour de l'equity
                    equity *= 1 + (profit_pct / 100 * risk_percent * risk_reward)
                    equity_curve.append({'Date': exit_date, 'Equity': equity})
                    
                    # Déterminer si le trade est gagnant
                    risk_amount = entry_price * risk_percent
                    reward_amount = risk_amount * risk_reward
                    
                    if current_position == 1:  # Achat
                        is_win = (exit_price - entry_price) >= reward_amount
                        is_loss = (entry_price - exit_price) >= risk_amount
                    else:  # Vente
                        is_win = (entry_price - exit_price) >= reward_amount
                        is_loss = (exit_price - entry_price) >= risk_amount
                    
                    if not is_win and not is_loss:
                        is_win = profit_pct > 0
                    
                    results.append({
                        'Entry Date': entry_date,
                        'Position': current_position,
                        'Entry Price': entry_price,
                        'Exit Date': exit_date,
                        'Exit Price': exit_price,
                        'Days Held': days_held,
                        'Profit Pct': profit_pct,
                        'Is Win': is_win
                    })
                    
                    # Réinitialisation
                    in_position = False
                    current_position = 0
        
        self.trade_results = pd.DataFrame(results)
        
        # Calcul des métriques de performance
        if len(results) > 0:
            # Rentabilité totale
            total_return = (equity / 10000 - 1) * 100  # En pourcentage
            
            # Taux de réussite
            win_rate = self.trade_results['Is Win'].mean() * 100
            
            # Gain/Perte moyen
            winning_trades = self.trade_results[self.trade_results['Is Win']]
            losing_trades = self.trade_results[~self.trade_results['Is Win']]
            
            avg_win = winning_trades['Profit Pct'].mean() if len(winning_trades) > 0 else 0
            avg_loss = losing_trades['Profit Pct'].mean() if len(losing_trades) > 0 else 0
            
            # Drawdown maximal
            equity_df = pd.DataFrame(equity_curve).set_index('Date')
            rolling_max = equity_df['Equity'].cummax()
            drawdown = (equity_df['Equity'] - rolling_max) / rolling_max
            max_drawdown = drawdown.min() * 100  # En pourcentage
            
            # Ratio de Sharpe (simplifié)
            returns = self.trade_results['Profit Pct'] / 100
            sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252) if len(returns) > 1 and returns.std() != 0 else 0
            
            # Nombre de trades
            num_trades = len(self.trade_results)
            
            self.performance_metrics = {
                'Total Return': total_return,
                'Win Rate': win_rate,
                'Avg Win': avg_win,
                'Avg Loss': avg_loss,
                'Max Drawdown': max_drawdown,
                'Sharpe Ratio': sharpe_ratio,
                'Number of Trades': num_trades
            }
        else:
            self.performance_metrics = None
    
    def show_results(self):
        """Affiche les résultats de performance"""
        for widget in self.results_frame.winfo_children():
            if not isinstance(widget, ttk.Button):  # Conserve le bouton "Afficher Graphique"
                widget.destroy()
        
        if not hasattr(self, 'performance_metrics') or self.performance_metrics is None:
            ttk.Label(self.results_frame, text="Aucun trade à afficher").pack()
            return
        
        metrics = self.performance_metrics
        
        # Cadre pour les métriques
        metrics_frame = ttk.Frame(self.results_frame)
        metrics_frame.pack(fill=tk.X, pady=5)
        
        # Affichage des métriques
        ttk.Label(metrics_frame, text="Rentabilité totale:", font=('Helvetica', 9, 'bold')).grid(row=0, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Total Return']:.2f}%", 
                 foreground="green" if metrics['Total Return'] >= 0 else "red").grid(row=0, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Taux de réussite:", font=('Helvetica', 9, 'bold')).grid(row=1, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Win Rate']:.2f}%").grid(row=1, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Gain moyen:", font=('Helvetica', 9, 'bold')).grid(row=2, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Avg Win']:.2f}%", foreground="green").grid(row=2, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Perte moyenne:", font=('Helvetica', 9, 'bold')).grid(row=3, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Avg Loss']:.2f}%", foreground="red").grid(row=3, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Drawdown max:", font=('Helvetica', 9, 'bold')).grid(row=4, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Max Drawdown']:.2f}%", 
                 foreground="red" if metrics['Max Drawdown'] < 0 else "black").grid(row=4, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Ratio de Sharpe:", font=('Helvetica', 9, 'bold')).grid(row=5, column=0, sticky="w")
        sharpe_color = "green" if metrics['Sharpe Ratio'] > 1 else "orange" if metrics['Sharpe Ratio'] > 0 else "red"
        ttk.Label(metrics_frame, text=f"{metrics['Sharpe Ratio']:.2f}", foreground=sharpe_color).grid(row=5, column=1, sticky="e")
        
        ttk.Label(metrics_frame, text="Nombre de trades:", font=('Helvetica', 9, 'bold')).grid(row=6, column=0, sticky="w")
        ttk.Label(metrics_frame, text=f"{metrics['Number of Trades']}").grid(row=6, column=1, sticky="e")
        
        # Tableau des trades
        tree_frame = ttk.Frame(self.results_frame)
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        tree = ttk.Treeview(tree_frame, columns=('Entry', 'Position', 'Entry Price', 'Exit', 'Exit Price', 'Days', 'Profit', 'Result'), show='headings', height=5)
        
        tree.heading('Entry', text='Date Entrée')
        tree.heading('Position', text='Position')
        tree.heading('Entry Price', text='Prix Entrée')
        tree.heading('Exit', text='Date Sortie')
        tree.heading('Exit Price', text='Prix Sortie')
        tree.heading('Days', text='Jours')
        tree.heading('Profit', text='Profit (%)')
        tree.heading('Result', text='Résultat')
        
        tree.column('Entry', width=80)
        tree.column('Position', width=60)
        tree.column('Entry Price', width=80)
        tree.column('Exit', width=80)
        tree.column('Exit Price', width=80)
        tree.column('Days', width=50)
        tree.column('Profit', width=70)
        tree.column('Result', width=70)
        
        for _, trade in self.trade_results.iterrows():
            result = "Gagnant" if trade['Is Win'] else "Perdant"
            color = 'green' if trade['Is Win'] else 'red'
            
            tree.insert('', 'end', values=(
                trade['Entry Date'].strftime('%Y-%m-%d'),
                'Achat' if trade['Position'] == 1 else 'Vente',
                f"{trade['Entry Price']:.2f}",
                trade['Exit Date'].strftime('%Y-%m-%d'),
                f"{trade['Exit Price']:.2f}",
                trade['Days Held'],
                f"{trade['Profit Pct']:.2f}%",
                result
            ), tags=(color,))
        
        tree.tag_configure('green', foreground='green')
        tree.tag_configure('red', foreground='red')
        
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        tree.pack(fill=tk.BOTH, expand=True)
    
    def plot_results(self):
        """Affiche les résultats graphiques"""
        if hasattr(self, 'graph_canvas'):
            self.graph_canvas.get_tk_widget().destroy()
        
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 6), gridspec_kw={'height_ratios': [3, 1]})
        
        # Graphique des prix
        ax1.plot(self.data_recent.index, self.data_recent['Close'], label='Prix', color='blue', alpha=0.6)
        
        # Afficher les signaux d'entrée
        if hasattr(self, 'trade_results') and not self.trade_results.empty:
            buy_signals = self.trade_results[self.trade_results['Position'] == 1]
            sell_signals = self.trade_results[self.trade_results['Position'] == -1]
            
            ax1.scatter(
                buy_signals['Entry Date'], buy_signals['Entry Price'],
                label='Achat', marker='^', color='green', s=100
            )
            ax1.scatter(
                sell_signals['Entry Date'], sell_signals['Entry Price'],
                label='Vente', marker='v', color='red', s=100
            )
        
        # Graphique de l'indicateur
        indicator = self.indicator_var.get()
        if indicator == "MACD":
            ax2.plot(self.data_recent.index, self.data_recent['MACD'], label='MACD', color='blue')
            ax2.plot(self.data_recent.index, self.data_recent['Signal'], label='Signal', color='orange')
        elif indicator == "RSI":
            ax2.plot(self.data_recent.index, self.data_recent['RSI'], label='RSI', color='purple')
            ax2.axhline(70, color='red', linestyle='--')
            ax2.axhline(30, color='green', linestyle='--')
        elif indicator == "Bollinger Bands":
            ax1.plot(self.data_recent.index, self.data_recent['Upper'], label='Bande Sup', linestyle='--', color='red')
            ax1.plot(self.data_recent.index, self.data_recent['Lower'], label='Bande Inf', linestyle='--', color='green')
            ax1.fill_between(
                self.data_recent.index, self.data_recent['Upper'], self.data_recent['Lower'],
                color='gray', alpha=0.1
            )
        elif indicator == "Stochastic":
            ax2.plot(self.data_recent.index, self.data_recent['%K'], label='%K', color='blue')
            ax2.plot(self.data_recent.index, self.data_recent['%D'], label='%D', color='orange')
            ax2.axhline(80, color='red', linestyle='--')
            ax2.axhline(20, color='green', linestyle='--')
        elif indicator == "Parabolic SAR":
            ax1.scatter(
                self.data_recent.index, self.data_recent['SAR'],
                label='SAR', marker='o', color='red', s=10
            )
        elif indicator == "ATR":
            ax2.plot(self.data_recent.index, self.data_recent['ATR'], label='ATR', color='blue')
        elif indicator == "OBV":
            ax2.plot(self.data_recent.index, self.data_recent['OBV'], label='OBV', color='blue')
        
        ax1.set_title(f"Analyse {indicator} - Signaux de Trading")
        ax1.legend()
        ax1.grid(True)
        
        ax2.set_title(indicator)
        ax2.legend()
        ax2.grid(True)
        
        plt.tight_layout()
        
        # Intégration dans Tkinter
        self.graph_canvas = FigureCanvasTkAgg(fig, master=self.graph_frame)
        self.graph_canvas.draw()
        self.graph_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

if __name__ == "__main__":
    root = tk.Tk()
    app = TechnicalAnalysisApp(root)
    root.mainloop()